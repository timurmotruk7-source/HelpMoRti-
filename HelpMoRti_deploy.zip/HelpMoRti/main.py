import asyncio
import logging
import os
import sqlite3

from groq import Groq
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)

BOT_TOKEN = os.getenv("BOT_TOKEN")
GROQ_API_KEY = os.getenv("GROQ_API_KEY")

if not BOT_TOKEN or not GROQ_API_KEY:
    raise RuntimeError(
        "Set BOT_TOKEN and GROQ_API_KEY in the hosting service environment variables."
    )

client = Groq(api_key=GROQ_API_KEY)
MODEL = "openai/gpt-oss-20b"
DB = os.getenv("DB_PATH", "helpmorti.db")

MODES = {
    "assistant": (
        "Ты HelpMoRti, дружелюбный личный ИИ-помощник. "
        "Помогай с повседневными вопросами."
    ),
    "study": (
        "Ты помощник по учёбе. Объясняй материал простым языком, "
        "приводи примеры и помогай разобраться."
    ),
    "coding": (
        "Ты опытный помощник по программированию. "
        "Объясняй код, находи ошибки и предлагай решения."
    ),
    "writer": (
        "Ты помощник по написанию текстов. "
        "Помогай создавать грамотные и интересные тексты."
    ),
}

MODE_NAMES = {
    "assistant": "🧠 Помощник",
    "study": "📚 Учёба",
    "coding": "💻 Программирование",
    "writer": "✍️ Тексты",
}


def init_db():
    with sqlite3.connect(DB) as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS history (
                user_id INTEGER,
                role TEXT,
                content TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                user_id INTEGER PRIMARY KEY,
                mode TEXT DEFAULT 'assistant'
            )
        """)


def get_mode(user_id):
    with sqlite3.connect(DB) as conn:
        row = conn.execute(
            "SELECT mode FROM settings WHERE user_id = ?", (user_id,)
        ).fetchone()
    return row[0] if row else "assistant"


def set_mode(user_id, mode):
    with sqlite3.connect(DB) as conn:
        conn.execute("""
            INSERT INTO settings (user_id, mode)
            VALUES (?, ?)
            ON CONFLICT(user_id)
            DO UPDATE SET mode = excluded.mode
        """, (user_id, mode))


def get_history(user_id):
    with sqlite3.connect(DB) as conn:
        rows = conn.execute("""
            SELECT role, content FROM (
                SELECT rowid, role, content
                FROM history
                WHERE user_id = ?
                ORDER BY rowid DESC
                LIMIT 12
            )
            ORDER BY rowid ASC
        """, (user_id,)).fetchall()
    return [{"role": role, "content": content} for role, content in rows]


def save_message(user_id, role, content):
    with sqlite3.connect(DB) as conn:
        conn.execute(
            "INSERT INTO history (user_id, role, content) VALUES (?, ?, ?)",
            (user_id, role, content),
        )
        conn.execute("""
            DELETE FROM history
            WHERE user_id = ?
            AND rowid NOT IN (
                SELECT rowid FROM history
                WHERE user_id = ?
                ORDER BY rowid DESC
                LIMIT 12
            )
        """, (user_id, user_id))


def clear_history(user_id):
    with sqlite3.connect(DB) as conn:
        conn.execute("DELETE FROM history WHERE user_id = ?", (user_id,))


def main_menu():
    keyboard = [
        [
            InlineKeyboardButton("🧠 Помощник", callback_data="assistant"),
            InlineKeyboardButton("📚 Учёба", callback_data="study"),
        ],
        [
            InlineKeyboardButton("💻 Программирование", callback_data="coding"),
            InlineKeyboardButton("✍️ Тексты", callback_data="writer"),
        ],
        [InlineKeyboardButton("🧹 Очистить историю", callback_data="clear")],
    ]
    return InlineKeyboardMarkup(keyboard)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Привет! Я HelpMoRti 🤖\n\n"
        "Твой личный ИИ-помощник.\n"
        "Выбирай режим работы в меню или просто задавай вопросы!",
        reply_markup=main_menu(),
    )


async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Выбери нужный режим:", reply_markup=main_menu()
    )


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    choice = query.data

    if choice == "clear":
        clear_history(user_id)
        await query.edit_message_text(
            "История диалога очищена! 🧹\n\nМожешь начать новый разговор.",
            reply_markup=main_menu(),
        )
        return

    if choice in MODES:
        set_mode(user_id, choice)
        await query.edit_message_text(
            f"Режим изменён!\n\nСейчас активен: {MODE_NAMES[choice]}\n\n"
            "Напиши мне сообщение.",
            reply_markup=main_menu(),
        )


async def answer(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_text = update.message.text
    mode = get_mode(user_id)
    history = get_history(user_id)

    messages = [{
        "role": "system",
        "content": (
            "Ты HelpMoRti. Отвечай на русском языке, если пользователь "
            "не просит другой язык. Будь дружелюбным, понятным и честным. "
            + MODES[mode]
        ),
    }]
    messages.extend(history)
    messages.append({"role": "user", "content": user_text})

    await update.message.chat.send_action("typing")

    try:
        response = await asyncio.to_thread(
            client.chat.completions.create,
            model=MODEL,
            messages=messages,
            max_completion_tokens=800,
        )
        reply = response.choices[0].message.content
        if not reply:
            reply = "Не получилось сформировать ответ. Попробуй ещё раз."

        save_message(user_id, "user", user_text)
        save_message(user_id, "assistant", reply)

        for i in range(0, len(reply), 4000):
            await update.message.reply_text(reply[i:i + 4000])

    except Exception:
        logging.exception("Groq error")
        await update.message.reply_text(
            "Произошла ошибка при обращении к ИИ. Попробуй позже."
        )


def main():
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("menu", menu))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, answer)
    )
    logging.info("HelpMoRti 2.0 запущен!")
    app.run_polling()


if __name__ == "__main__":
    main()
