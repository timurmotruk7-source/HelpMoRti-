# HelpMoRti 2.0

Telegram AI assistant using Groq and python-telegram-bot.

## Environment variables

Set these in your hosting provider's environment/secrets settings:

- `BOT_TOKEN` — Telegram bot token from BotFather
- `GROQ_API_KEY` — Groq API key

Optional:
- `DB_PATH` — SQLite database path (defaults to `helpmorti.db`)

## Run locally

```bash
pip install -r requirements.txt
python main.py
```

Do not commit API keys, Telegram tokens, `.env`, or the SQLite database.
